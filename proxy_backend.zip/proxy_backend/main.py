"""FastAPI proxy for the TARS /ask endpoint.

This proxy enforces the strict response contract expected by the Flutter
frontend while remaining transparent to the upstream AI service.
"""
from __future__ import annotations

import os
import re
from enum import Enum
from typing import Dict, List, Optional

import httpx
import json
from fastapi import FastAPI, HTTPException, status, Body, Response
from pydantic import BaseModel, Field

MANUAL_PATH = os.path.join(os.path.dirname(__file__), "..", "assets", "tally_manual.json")
TALLY_MANUAL = {"tutorials": []}

def load_manual():
    global TALLY_MANUAL
    try:
        if os.path.exists(MANUAL_PATH):
            with open(MANUAL_PATH, "r", encoding="utf-8") as f:
                TALLY_MANUAL = json.load(f)
            print(f"Loaded manual with {len(TALLY_MANUAL.get('tutorials', []))} tutorials.")
    except Exception as e:
        print(f"Failed to load manual: {e}")

load_manual()

def search_manual(query: str) -> Optional[dict]:
    """Search for relevant manual entries and return the best tutorial object."""
    if not query:
        return None
    
    query_terms = [t for t in query.lower().replace(",", " ").split() if len(t) > 2]
    if not query_terms:
        # Fallback to a few common terms if the query is very short but known
        query_terms = [query.lower().strip()]
        
    best_tutorial = None
    max_score = 0
    matched_term = None
    
    for tutorial in TALLY_MANUAL.get("tutorials", []):
        score = 0
        title = tutorial.get("title", "").lower()
        learning = tutorial.get("learning", "").lower()
        
        current_matched_term = None
        for term in query_terms:
            if term in title:
                score += 5
                current_matched_term = term
            if term in learning:
                score += 1
                if not current_matched_term:
                    current_matched_term = term
                
        if score > max_score:
            max_score = score
            best_tutorial = tutorial
            matched_term = current_matched_term
            
    # Threshold lowered to 1 as requested
    if best_tutorial and max_score >= 1:
        # Implement Sliding Window: 1250 chars before and after the matched term (2500 total)
        # Smaller windows help avoid upstream token limits/cutoffs
        content = best_tutorial['learning']
        if matched_term:
            idx = content.lower().find(matched_term.lower())
            if idx != -1:
                start = max(0, idx - 1250)
                end = min(len(content), idx + 1250)
                snippet = content[start:end]
                if start > 0: snippet = "..." + snippet
                if end < len(content): snippet = snippet + "..."
                return {
                    "title": best_tutorial['title'],
                    "learning": snippet
                }
        
        # Fallback to first 2500 if no term match found
        return {
            "title": best_tutorial['title'],
            "learning": content[:2500]
        }
    return None

UPSTREAM_ASK_URL = os.getenv("UPSTREAM_ASK_URL", "https://tars-jdno.onrender.com/ask")
HTTP_TIMEOUT_SECONDS = float(os.getenv("UPSTREAM_TIMEOUT_SECONDS", "120"))
ESCALATION_MESSAGE = (
    "This issue needs review by a support executive to ensure it’s resolved correctly. "
    "I’ve noted this under your ticket, and our support team will assist you shortly."
)
REQUIRED_SECTION_HEADERS = [
    "Step 1:",
    "Step 2:",
    "Step 3:",
]
CUSTOMER_ISSUE_PATTERN = re.compile(r"Customer issue:\s*(.+)", re.IGNORECASE | re.DOTALL)
DEFAULT_ISSUE_SUMMARY = "your issue"
SYSTEM_KEYWORDS = {
    "not opening",
    "won't open",
    "wont open",
    "unable to start",
    "startup",
    "crash",
    "crashing",
    "freezing",
    "freeze",
    "license",
    "licence",
    "activation",
    "blank screen",
    "install",
    "installation",
    "system",
    "login",
    "password",
    "error",
    "500",
    "access",
    "slow",
}
FUNCTIONAL_KEYWORDS = {
    "invoice",
    "gst",
    "tax",
    "ledger",
    "report",
    "reconcile",
    "recon",
    "stock",
    "inventory",
    "discount",
    "entry",
    "voucher",
    "sales",
    "purchase",
    "bill",
    "receipt",
    "bank",
    "import",
    "export",
    "screen",
    "flicker",
    "flickering",
    "display",
    "button",
}


class IssueCategory(str, Enum):
    """High-level issue types used to steer deterministic responses."""

    FUNCTIONAL = "KNOWN_TALLY_FUNCTIONAL"
    SYSTEM = "SYSTEM_OR_ENVIRONMENT"
    UNKNOWN = "UNKNOWN_OR_INSUFFICIENT"


class ScreenContext(BaseModel):
    screen_name: Optional[str] = Field(default=None, alias="screen_name")
    active_field: Optional[str] = Field(default=None, alias="active_field")
    field_values: Dict[str, str] = Field(default_factory=dict, alias="field_values")

    class Config:
        populate_by_name = True


class AskRequest(BaseModel):
    context: Optional[ScreenContext] = None
    question: str = Field(..., alias="customer_issue")
    ticket_id: int = Field(..., alias="ticket_id")
    persona_prompt: Optional[str] = Field(default=None, alias="persona_prompt")
    auto_coach: bool = Field(default=False, alias="auto_coach")

    class Config:
        populate_by_name = True


class AskResponse(BaseModel):
    answer: str

    class Config:
        extra = "allow"

app = FastAPI(title="TARS Structured Proxy", version="1.0.0")


@app.post(
    "/ask",
    response_model=AskResponse,
    summary="Proxy the /ask call while enforcing structured responses",
)
async def proxy_ask(
    response: Response,
    payload: AskRequest = Body(
        ...,
        example={
            "customer_issue": "Tally not opening on startup",
            "ticket_id": 12345,
            "auto_coach": True
        }
    )
) -> AskResponse:
    issue_text = extract_issue_text(payload)

    # 1. Manual Grounding Implementation
    best_tutorial = search_manual(issue_text)
    
    # 2. Consolidated High-Compliance Question
    # We put rules here because upstream seems to ignore persona_prompt
    enriched_question = f"""
STRICT RULES: Use ONLY the manual data. No platitudes. Use "Step 1/2/3" structure.
If answer not in manual, use: "This issue needs review by a support executive. I've noted this in your ticket."

MANUAL DATA:
{best_tutorial['learning'] if best_tutorial else 'No relevant manual data found.'}

USER ISSUE:
{issue_text}
"""
    if ticket_id:
        enriched_question = f"Ticket ID: {ticket_id}\n{enriched_question}"

    # 3. Prepare payload for upstream
    # We strip 'context' and 'persona_prompt' to leave maximum token room for the answer.
    upstream_payload = {
        "question": enriched_question.strip(),
        "auto_coach": False,
    }

    print(f"[DEBUG] Issue Text Extracted: {issue_text}")
    print(f"[DEBUG] Upstream Payload Sent (Lean Mode)")

    try:
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT_SECONDS) as client:
            upstream_response = await client.post(
                UPSTREAM_ASK_URL,
                json=upstream_payload,
            )
    except httpx.RequestError as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Upstream request failed: {exc}",
        ) from exc

    if upstream_response.status_code != status.HTTP_200_OK:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Upstream returned {upstream_response.status_code}: {upstream_response.text}",
        )

    try:
        data = upstream_response.json()
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Upstream response was not valid JSON.",
        ) from exc

    upstream_answer = data.get("answer")
    if not isinstance(upstream_answer, str) or not upstream_answer.strip():
        # Fall back to an empty string so the normalizer rebuilds the response.
        upstream_answer = ""

    print(f"[DEBUG] Upstream Raw Length: {len(upstream_answer)}")
    
    normalized_answer = normalize_response(issue_text, upstream_answer)
    print(f"[DEBUG] Final Response Length: {len(normalized_answer)}")
    
    response.headers["X-Debug-Source"] = "TARS-Proxy-Backend"
    response.headers["X-Issue-Detected"] = issue_text[:50]
    
    return AskResponse(answer=normalized_answer)


async def fetch_upstream_answer(payload: AskRequest) -> str:
    """Call the upstream AI service and extract the answer string."""

    try:
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT_SECONDS) as client:
            response = await client.post(
                UPSTREAM_ASK_URL,
                json=payload.dict(by_alias=True, exclude_none=True),
            )
    except httpx.RequestError as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Upstream request failed: {exc}",
        ) from exc

    if response.status_code != status.HTTP_200_OK:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Upstream returned {response.status_code}: {response.text}",
        )

    try:
        data = response.json()
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Upstream response was not valid JSON.",
        ) from exc

    answer = data.get("answer")
    if not isinstance(answer, str) or not answer.strip():
        # Fall back to an empty string so the normalizer rebuilds the response.
        return ""
    return answer.strip()


def extract_issue_text(payload: AskRequest) -> str:
    """Heuristically pull the customer's issue text based on mode (Auto-Coach vs Manual)."""

    question = payload.question.strip() if payload.question else ""

    # Helper to try finding issue in persona/context
    def _try_context_extraction() -> Optional[str]:
        # 1. Try persona prompt
        if payload.persona_prompt:
            # Try to grab "Customer issue:" part if present
            match = CUSTOMER_ISSUE_PATTERN.search(payload.persona_prompt)
            if match:
                candidate = match.group(1).strip()
                if candidate:
                    return sanitize_issue(candidate)
            # Otherwise use the whole prompt (opaque text)
            combined = sanitize_issue(payload.persona_prompt)
            if combined:
                return combined

        # 2. Try context fields
        if payload.context and payload.context.field_values:
            for key in ("issue", "title", "description", "problem", "summary"):
                value = payload.context.field_values.get(key)
                if value:
                    return sanitize_issue(value)
        return None

    # Rule A: Auto-Coach Mode
    if payload.auto_coach:
        # Prioritize ticket context / persona prompt
        issue = _try_context_extraction()
        if issue:
            return issue
        # Fallback to question if context is empty
        if question:
            return sanitize_issue(question)

    # Rule B: Manual Chat Mode
    else:
        # Prioritize explicit user question
        if question:
            return sanitize_issue(question)
        # Fallback to context/persona if user sent empty question (rare/edge case)
        # (Same logic as Auto-Coach at this point as a fallback)
        issue = _try_context_extraction()
        if issue:
            return issue

    return DEFAULT_ISSUE_SUMMARY


def sanitize_issue(issue: str) -> str:
    """Clean up noisy whitespace and trailing punctuation."""
    if not issue:
        return ""
    compact = re.sub(r"\s+", " ", issue).strip()
    return compact.rstrip(" :") or DEFAULT_ISSUE_SUMMARY


def normalize_response(issue_text: str, raw_answer: str) -> str:
    """Ensure the answer conforms to the mandatory section contract.

    If the upstream response is missing required headers, repair it using the AI's
    content instead of discarding it entirely.
    """

    answer = (raw_answer or "").strip()
    # Check if we have headers AND meaningful content in Solution
    if answer and has_required_sections(answer) and sections_non_empty(answer):
        return answer

    category = classify_issue(issue_text)
    repairers = {
        IssueCategory.SYSTEM: _repair_system_response,
        IssueCategory.FUNCTIONAL: _repair_functional_response,
        IssueCategory.UNKNOWN: _repair_unknown_response,
    }
    repairer = repairers.get(category, _repair_unknown_response)
    # Pass the raw answer so the repairer can attempt to extract a partial solution
    return repairer(issue_text=issue_text, ai_content=answer)


def has_required_sections(answer: str) -> bool:
    """Check whether all required headings exist in the payload."""

    return all(section in answer for section in REQUIRED_SECTION_HEADERS)


def sections_non_empty(answer: str) -> bool:
    """Verify mandatory sections have content. Disabled threshold for testing."""
    # We check for Step 1/2 headers instead of Solution:
    if "Step 1" in answer or "Step 2" in answer:
        return True
    return False


def classify_issue(issue_text: str) -> IssueCategory:
    """Rough classification used to steer the normalized template."""

    normalized = issue_text.lower()
    if not normalized or len(normalized) < 12:
        return IssueCategory.UNKNOWN

    if any(keyword in normalized for keyword in SYSTEM_KEYWORDS):
        return IssueCategory.SYSTEM

    if any(keyword in normalized for keyword in FUNCTIONAL_KEYWORDS):
        return IssueCategory.FUNCTIONAL

    return IssueCategory.UNKNOWN


def _extract_solution_from_ai_response(ai_content: str) -> str:
    """Extract the Solution section from a structured AI response."""
    if not ai_content:
        return ""
        
    lower = ai_content.lower()
    start_marker = "solution:"
    
    idx = lower.find(start_marker)
    if idx != -1:
        # Found explicit Solution header, use content after it
        return ai_content[idx + len(start_marker):].strip()
        
    # If no "Solution:" header found...
    # Check if other headers exist. If ANY other header exists, then this is a partial response w/o solution.
    has_any_header = any(h.lower().rstrip(":") in lower for h in REQUIRED_SECTION_HEADERS if "solution" not in h.lower())
    if has_any_header:
        # Contains Ack or Question but NO solution -> Return empty implementation
        return ""
        
    # No headers found at all? Assume the whole text is the solution (unstructured fallback)
    return ai_content.strip()


def _repair_functional_response(issue_text: str, *, ai_content: str = "") -> str:
    """Structured reply for functional issues, preferring AI content when provided."""

    issue_summary = issue_text or "the issue you reported"
    acknowledgement = (
        "Issue Acknowledgement:\n"
        f"• I understand you're facing an issue with {issue_summary} and am here to provide immediate technical guidance."
    )
    
    # Extract AI solution if present (and meaningful)
    extracted = _extract_solution_from_ai_response(ai_content)
    has_meaningful_solution = len(extracted) > 60 # Higher threshold to discard short/lazy answers
    
    solution_body = extracted if has_meaningful_solution else (
        "If A):\n"
        f"- Step 1: Re-open the exact form that led to {issue_summary} and validate every ledger, stock item, and tax field.\n"
        "- Step 2: Remove any highlighted rows, re-enter the values slowly, and confirm numbering/rounding rules.\n"
        "- Step 3: Save again and capture any precise error wording so I can escalate if it repeats.\n\n"
        "If B):\n"
        f"- Step 1: Open the saved document/report tied to {issue_summary} and confirm totals and filters look correct.\n"
        "- Step 2: Export to PDF first; if the export works but print/email fails, reset the print/report profile.\n"
        "- Step 3: Refresh or re-sync data and grab the exact error so we can trace it further."
    )
    solution = f"Solution:\n{solution_body}"
    return "\n\n".join([acknowledgement, solution]).strip()


def _repair_system_response(issue_text: str, *, ai_content: str = "") -> str:
    """Structured reply for environment/system issues, preferring AI content when provided."""

    issue_summary = issue_text or "the issue you reported"
    acknowledgement = (
        "Issue Acknowledgement:\n"
        f"• I understand you're facing an issue with {issue_summary}, which points to a system or environment concern."
    )
    
    extracted = _extract_solution_from_ai_response(ai_content)
    has_meaningful_solution = len(extracted) > 60

    solution_body = extracted if has_meaningful_solution else (
        "If A):\n"
        f"- Step 1: Close Tally, restart Windows, and try launching again to rule out a locked session behind {issue_summary}.\n"
        "- Step 2: Attempt opening in educational mode; if that also fails, the installation or license needs inspection.\n"
        f"- Step 3: {ESCALATION_MESSAGE}\n\n"
        "If B):\n"
        f"- Step 1: Capture the exact error, login prompt, or crash message shown during {issue_summary}.\n"
        "- Step 2: Avoid repeated retries so the current logs remain intact for diagnosis.\n"
        f"- Step 3: {ESCALATION_MESSAGE}"
    )
    solution = f"Solution:\n{solution_body}"
    return "\n\n".join([acknowledgement, solution]).strip()


def _repair_unknown_response(issue_text: str, *, ai_content: str = "") -> str:
    """Fallback structured reply when details are insufficient, preferring AI content when provided."""

    issue_summary = issue_text or "the issue you reported"
    acknowledgement = (
        "Issue Acknowledgement:\n"
        f"• I understand you're seeing {issue_summary}, but I need a few more details to provide a specific solution."
    )
    
    extracted = _extract_solution_from_ai_response(ai_content)
    has_meaningful_solution = len(extracted) > 60

    solution_body = extracted if has_meaningful_solution else (
        "- Step 1: Re-verify the data entries in any voucher or report mentioned.\n"
        "- Step 2: Ensure all Tally Prime system settings are at their defaults.\n"
        f"- Step 3: {ESCALATION_MESSAGE}"
    )
    solution = f"Solution:\n{solution_body}"
    return "\n\n".join([acknowledgement, solution]).strip()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "proxy_backend.main:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", "8000")),
        reload=os.getenv("ENV", "development") == "development",
    )
