import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:printing/printing.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:intl/intl.dart' hide TextDirection;
import 'dart:typed_data';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/rendering.dart';
import 'dart:ui' as ui;
import 'dart:math' as math;

// Tailwind Colors Mapping
const cGray50 = Color(0xFFF9FAFB);
const cGray100 = Color(0xFFF3F4F6);
const cGray200 = Color(0xFFE5E7EB);
const cGray300 = Color(0xFFD1D5DB);
const cGray400 = Color(0xFF9CA3AF);
const cGray500 = Color(0xFF6B7280);
const cGray600 = Color(0xFF4B5563);
const cGray700 = Color(0xFF374151);
const cGray800 = Color(0xFF1F2937);
const cGray900 = Color(0xFF111827);

const cBlue50 = Color(0xFFEFF6FF);
const cBlue100 = Color(0xFFDBEAFE);
const cBlue200 = Color(0xFFBFDBFE);
const cBlue400 = Color(0xFF60A5FA);
const cBlue500 = Color(0xFF3B82F6);
const cBlue600 = Color(0xFF2563EB);
const cBlue700 = Color(0xFF1D4ED8);

const cGreen50 = Color(0xFFF0FDF4);
const cGreen200 = Color(0xFFBBF7D0);
const cGreen300 = Color(0xFF86EFAC);
const cGreen400 = Color(0xFF4ADE80);
const cGreen600 = Color(0xFF16A34A);
const cGreen700 = Color(0xFF15803D);

const cIndigo50 = Color(0xFFEEF2FF);
const cEmerald50 = Color(0xFFECFDF5);
const cYellow50 = Color(0xFFFEFCE8);
const cYellow300 = Color(0xFFFDE047);
const cYellow400 = Color(0xFFFACC15);

const cSlate50 = Color(0xFFF8FAFC);
const cSlate100 = Color(0xFFF1F5F9);
const cSlate600 = Color(0xFF475569);
const cSlate700 = Color(0xFF334155);
const cSlate800 = Color(0xFF1E293B);

const cOrange50 = Color(0xFFFFF7ED);
const cOrange100 = Color(0xFFFFEDD5);
const cOrange600 = Color(0xFFEA580C);
const cOrange700 = Color(0xFFC2410C);
const cOrange800 = Color(0xFF9A3412);

const cPurple50 = Color(0xFFFAF5FF);
const cPurple100 = Color(0xFFF3E8FF);
const cPurple600 = Color(0xFF9333EA);
const cPurple700 = Color(0xFF7E22CE);
const cPurple800 = Color(0xFF6B21A8);

class LogoPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // scale to 100x100 space matching SVG
    final sx = size.width / 100;
    final sy = size.height / 100;
    canvas.scale(sx, sy);

    final p1 = Path()
      ..moveTo(50, 5)
      ..lineTo(90, 35)
      ..lineTo(75, 80)
      ..lineTo(25, 80)
      ..lineTo(10, 35)
      ..close();
    canvas.drawPath(
      p1,
      Paint()
        ..color = const Color(0xFF6BBE44)
        ..style = PaintingStyle.fill,
    );

    final p2 = Path()
      ..moveTo(5, 50)
      ..lineTo(35, 35)
      ..lineTo(45, 75)
      ..lineTo(15, 90)
      ..lineTo(0, 65)
      ..close();
    canvas.drawPath(
      p2,
      Paint()
        ..color = const Color(0xFF2E7DAE)
        ..style = PaintingStyle.fill,
    );

    final p3 = Path()
      ..moveTo(95, 50)
      ..lineTo(100, 65)
      ..lineTo(85, 90)
      ..lineTo(55, 75)
      ..lineTo(65, 35)
      ..close();
    canvas.drawPath(
      p3,
      Paint()
        ..color = const Color(0xFF2E7DAE)
        ..style = PaintingStyle.fill,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class ProposalGeneratorPage extends ConsumerStatefulWidget {
  const ProposalGeneratorPage({super.key});

  @override
  ConsumerState<ProposalGeneratorPage> createState() =>
      _ProposalGeneratorPageState();
}

class _ProposalGeneratorPageState extends ConsumerState<ProposalGeneratorPage> {
  bool isEditing = true;

  // GlobalKey so generatePdfData can capture the full on-screen preview.
  // SingleChildScrollView lays out its child at full natural height, so
  // boundary.toImage() captures EVERYTHING even if the user hasn't scrolled.
  final GlobalKey _previewKey = GlobalKey();

  final clientNameCtrl = TextEditingController(text: 'ABZ BUILDERS');
  final clientPhoneCtrl = TextEditingController(text: '90374 73301');
  final docNumberCtrl = TextEditingController(text: '183/25-26');
  final licensePriceCtrl = TextEditingController(text: '22500');
  final discountPercentCtrl = TextEditingController(text: '5');
  final installationPriceCtrl = TextEditingController(text: '1000');
  final mobileAppPriceCtrl = TextEditingController(text: '4500');
  final supportDaysCtrl = TextEditingController(text: '45');
  final supportPriceCtrl = TextEditingController(text: '3000');
  String industry = 'Manufacturing';

  final List<String> industries = [
    'Manufacturing',
    'Retail',
    'Services',
    'Trading',
    'Healthcare',
    'Education',
    'Hospitality',
    'Real Estate',
  ];

  String selectedTemplate = 'Modern Blu';

  final List<String> templates = [
    'Modern Blu',
    'Classic Green',
    'Enterprise Slate',
    'Minimalist Black',
    'Vibrant Orange',
    'Creative Purple',
  ];

  Map<String, dynamic> _getThemeColors() {
    switch (selectedTemplate) {
      case 'Classic Green':
        return {
          'primary': cGreen700,
          'secondary': cGreen600,
          'accent': cBlue600,
          'lightBg1': cGreen50,
          'lightBg2': cEmerald50,
          'lightBorder': cGreen200,
          'headerBg': cGreen600,
          'pdfPrimary': PdfColors.green800,
          'pdfSecondary': PdfColors.green600,
          'pdfAccent': PdfColors.blue700,
        };
      case 'Enterprise Slate':
        return {
          'primary': cSlate800,
          'secondary': cSlate600,
          'accent': cBlue600,
          'lightBg1': cSlate50,
          'lightBg2': cSlate100,
          'lightBorder': cSlate600,
          'headerBg': cSlate700,
          'pdfPrimary': PdfColors.blueGrey800,
          'pdfSecondary': PdfColors.blueGrey600,
          'pdfAccent': PdfColors.blue700,
        };
      case 'Minimalist Black':
        return {
          'primary': cGray900,
          'secondary': cGray700,
          'accent': cGray600,
          'lightBg1': cGray100,
          'lightBg2': cGray200,
          'lightBorder': cGray300,
          'headerBg': cGray900,
          'pdfPrimary': PdfColors.black,
          'pdfSecondary': PdfColors.grey800,
          'pdfAccent': PdfColors.grey600,
        };
      case 'Vibrant Orange':
        return {
          'primary': cOrange700,
          'secondary': cOrange600,
          'accent': cYellow400,
          'lightBg1': cOrange50,
          'lightBg2': cOrange100,
          'lightBorder': cOrange600,
          'headerBg': cOrange700,
          'pdfPrimary': PdfColors.deepOrange800,
          'pdfSecondary': PdfColors.deepOrange600,
          'pdfAccent': PdfColors.amber700,
        };
      case 'Creative Purple':
        return {
          'primary': cPurple700,
          'secondary': cPurple600,
          'accent': cPurple800,
          'lightBg1': cPurple50,
          'lightBg2': cPurple100,
          'lightBorder': cPurple600,
          'headerBg': cPurple700,
          'pdfPrimary': PdfColors.purple800,
          'pdfSecondary': PdfColors.purple600,
          'pdfAccent': PdfColors.pink700,
        };
      case 'Modern Blu':
      default:
        return {
          'primary': cBlue700,
          'secondary': cBlue600,
          'accent': cGreen600,
          'lightBg1': cBlue50,
          'lightBg2': cIndigo50,
          'lightBorder': cBlue200,
          'headerBg': cBlue600,
          'pdfPrimary': PdfColors.blue800,
          'pdfSecondary': PdfColors.blue600,
          'pdfAccent': PdfColors.green700,
        };
    }
  }

  @override
  void dispose() {
    clientNameCtrl.dispose();
    clientPhoneCtrl.dispose();
    docNumberCtrl.dispose();
    licensePriceCtrl.dispose();
    discountPercentCtrl.dispose();
    installationPriceCtrl.dispose();
    mobileAppPriceCtrl.dispose();
    supportDaysCtrl.dispose();
    supportPriceCtrl.dispose();
    super.dispose();
  }

  Map<String, double> calculatePricing() {
    double lPrice = double.tryParse(licensePriceCtrl.text) ?? 0;
    double dPercent = double.tryParse(discountPercentCtrl.text) ?? 0;
    double iPrice = double.tryParse(installationPriceCtrl.text) ?? 0;
    double mPrice = double.tryParse(mobileAppPriceCtrl.text) ?? 0;
    double sPrice = double.tryParse(supportPriceCtrl.text) ?? 0;

    double discount = lPrice * (dPercent / 100);
    double packagePrice = lPrice - discount;
    double gst = packagePrice * 0.18;
    double total = packagePrice + gst;
    double serviceValue = lPrice + iPrice + mPrice + sPrice;
    double savings = serviceValue - packagePrice;

    return {
      'discount': discount,
      'packagePrice': packagePrice,
      'gst': gst,
      'total': total,
      'serviceValue': serviceValue,
      'savings': savings,
      'lPrice': lPrice,
      'iPrice': iPrice,
      'mPrice': mPrice,
      'sPrice': sPrice,
    };
  }

  Future<Uint8List> generatePdfData() async {
    // 1) Capture the full-height preview from the RepaintBoundary.
    final boundary =
        _previewKey.currentContext?.findRenderObject()
            as RenderRepaintBoundary?;
    if (boundary == null) {
      throw Exception(
        'Preview not rendered yet – please wait a moment and try again.',
      );
    }

    // Use a modest pixel ratio (2×) to keep memory/time manageable.
    const double pixelRatio = 2.0;
    final ui.Image fullUiImage = await boundary.toImage(pixelRatio: pixelRatio);
    final int imgW = fullUiImage.width;
    final int imgH = fullUiImage.height;

    // 2) Slice into A4-proportioned pages directly from the captured image.
    final double a4Ratio = PdfPageFormat.a4.height / PdfPageFormat.a4.width;
    final double pageHeightPx = imgW * a4Ratio;
    final int numPages = math.max(1, (imgH / pageHeightPx).ceil());
    final Paint paint = Paint();

    final pdf = pw.Document();

    for (int i = 0; i < numPages; i++) {
      final int startY = (i * pageHeightPx).round();
      final int remaining = imgH - startY;
      final int sliceH = math.min(pageHeightPx.round(), remaining);
      if (sliceH <= 0) break;

      final recorder = ui.PictureRecorder();
      final canvas = ui.Canvas(recorder);

      // Fill full A4 height with white so shorter final page has clean padding.
      final int targetHeight = pageHeightPx.round();
      canvas.drawRect(
        Rect.fromLTWH(0, 0, imgW.toDouble(), targetHeight.toDouble()),
        paint..color = const Color(0xFFFFFFFF),
      );

      canvas.drawImageRect(
        fullUiImage,
        Rect.fromLTWH(
          0,
          startY.toDouble(),
          imgW.toDouble(),
          sliceH.toDouble(),
        ),
        Rect.fromLTWH(0, 0, imgW.toDouble(), sliceH.toDouble()),
        paint,
      );

      final picture = recorder.endRecording();
      final croppedImage = await picture.toImage(imgW, targetHeight);
      final cropData = await croppedImage.toByteData(
        format: ui.ImageByteFormat.png,
      );
      final slicePng = cropData!.buffer.asUint8List();

      pdf.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          margin: pw.EdgeInsets.zero,
          build: (pw.Context ctx) => pw.FullPage(
            ignoreMargins: true,
            child: pw.Image(pw.MemoryImage(slicePng), fit: pw.BoxFit.cover),
          ),
        ),
      );
    }

    return pdf.save();
  }

  void _shareOrDownloadPdf() async {
    try {
      final pdfData = await generatePdfData();
      final filename = 'Proposal_${clientNameCtrl.text}.pdf';
      await Printing.sharePdf(bytes: pdfData, filename: filename);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    }
  }

  Future<void> _shareOnWhatsApp() async {
    final pricing = calculatePricing();
    final bonusDate = DateFormat(
      'd/M/yyyy',
    ).format(DateTime.now().add(const Duration(days: 5)));
    final message =
        '''Hi ${clientNameCtrl.text},

Here is your TallyPrime proposal from Sidharth IT Solutions:
- Package Price (before GST): ₹${pricing['packagePrice']!.toStringAsFixed(0)}
- GST (18%): ₹${pricing['gst']!.toStringAsFixed(0)}
- Total Investment: ₹${pricing['total']!.toStringAsFixed(0)}
- Savings vs individual services: ₹${pricing['savings']!.toStringAsFixed(0)}

Confirm by $bonusDate to reserve priority installation and extended support.
--
Sidharth IT Solutions''';

    final uri = Uri.parse(
      'https://wa.me/?text=${Uri.encodeComponent(message)}',
    );

    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Unable to open WhatsApp')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final pricing = calculatePricing();
    final today = DateFormat('d/M/yyyy').format(DateTime.now());
    final bonusDate = DateFormat(
      'd/M/yyyy',
    ).format(DateTime.now().add(const Duration(days: 5)));
    final themeColors = _getThemeColors();

    return Scaffold(
      backgroundColor: cGray100,
      body: Column(
        children: [
          // HEADER (Matches sticky top-0 border-b-2 border-blue-600)
          Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(bottom: BorderSide(color: cBlue600, width: 2)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            child: SafeArea(
              bottom: false,
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: cGray900),
                    onPressed: () {
                      if (Navigator.of(context).canPop()) {
                        Navigator.of(context).pop();
                      } else {
                        // If accessed directly or deep-linked, default somewhere safe
                        context.go('/');
                      }
                    },
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text(
                          'Sidharth IT Solutions - Proposal Generator',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: cGray900,
                          ),
                        ),
                        Text(
                          'Create customized TallyPrime proposals',
                          style: TextStyle(fontSize: 13, color: cGray600),
                        ),
                      ],
                    ),
                  ),
                  // Preview / Edit Button
                  ElevatedButton.icon(
                    icon: Icon(
                      isEditing ? LucideIcons.eye : LucideIcons.edit2,
                      size: 16,
                    ),
                    label: Text(isEditing ? 'Preview' : 'Edit'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: isEditing ? cGray200 : cBlue600,
                      foregroundColor: isEditing ? cGray700 : Colors.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    onPressed: () => setState(() => isEditing = !isEditing),
                  ),
                  const SizedBox(width: 12),
                  // Download PDF Button
                  ElevatedButton.icon(
                    icon: const Icon(LucideIcons.download, size: 16),
                    label: const Text('Download PDF'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: cGreen600,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    onPressed: _shareOrDownloadPdf,
                  ),
                  const SizedBox(width: 12),
                  ElevatedButton.icon(
                    icon: const Icon(LucideIcons.messageCircle, size: 16),
                    label: const Text('Share on WhatsApp'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF25D366),
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    onPressed: _shareOnWhatsApp,
                  ),
                ],
              ),
            ),
          ),

          // MAIN CONTENT AREA
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1200),
                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      final isNarrow = constraints.maxWidth < 1000;
                      final editPanel = isEditing
                          ? Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(8),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Colors.black12,
                                    blurRadius: 4,
                                    offset: Offset(0, 2),
                                  ),
                                ],
                              ),
                              padding: const EdgeInsets.all(24),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: const [
                                      Icon(
                                        LucideIcons.edit2,
                                        size: 20,
                                        color: cGray900,
                                      ),
                                      SizedBox(width: 8),
                                      Text(
                                        'Edit Proposal Details',
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: cGray900,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 24),
                                  _buildInput('Client Name', clientNameCtrl),
                                  _buildInput('Client Phone', clientPhoneCtrl),
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 16),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          'Industry',
                                          style: TextStyle(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w600,
                                            color: cGray700,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 12,
                                          ),
                                          decoration: BoxDecoration(
                                            border: Border.all(color: cGray300),
                                            borderRadius: BorderRadius.circular(
                                              4,
                                            ),
                                          ),
                                          child: DropdownButtonHideUnderline(
                                            child: DropdownButton<String>(
                                              value: industry,
                                              isExpanded: true,
                                              items: industries.map((
                                                String value,
                                              ) {
                                                return DropdownMenuItem<String>(
                                                  value: value,
                                                  child: Text(
                                                    value,
                                                    style: const TextStyle(
                                                      fontSize: 14,
                                                    ),
                                                  ),
                                                );
                                              }).toList(),
                                              onChanged: (String? newValue) {
                                                setState(() {
                                                  if (newValue != null) {
                                                    industry = newValue;
                                                  }
                                                });
                                              },
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 16),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          'Template',
                                          style: TextStyle(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w600,
                                            color: cGray700,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 12,
                                          ),
                                          decoration: BoxDecoration(
                                            border: Border.all(color: cGray300),
                                            borderRadius: BorderRadius.circular(
                                              4,
                                            ),
                                          ),
                                          child: DropdownButtonHideUnderline(
                                            child: DropdownButton<String>(
                                              value: selectedTemplate,
                                              isExpanded: true,
                                              items: templates.map((
                                                String value,
                                              ) {
                                                return DropdownMenuItem<String>(
                                                  value: value,
                                                  child: Text(
                                                    value,
                                                    style: const TextStyle(
                                                      fontSize: 14,
                                                    ),
                                                  ),
                                                );
                                              }).toList(),
                                              onChanged: (String? newValue) {
                                                setState(() {
                                                  if (newValue != null) {
                                                    selectedTemplate = newValue;
                                                  }
                                                });
                                              },
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  _buildInput('Doc Number', docNumberCtrl),

                                  const Padding(
                                    padding: EdgeInsets.symmetric(vertical: 8),
                                    child: Divider(color: cGray200),
                                  ),
                                  Text(
                                    'Pricing',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: themeColors['secondary'],
                                    ),
                                  ),
                                  const SizedBox(height: 16),

                                  _buildInput(
                                    'License Price (₹)',
                                    licensePriceCtrl,
                                    isNumber: true,
                                  ),
                                  _buildInput(
                                    'Discount (%)',
                                    discountPercentCtrl,
                                    isNumber: true,
                                  ),
                                  _buildInput(
                                    'Installation Price (₹)',
                                    installationPriceCtrl,
                                    isNumber: true,
                                  ),
                                  _buildInput(
                                    'Mobile App Price (₹)',
                                    mobileAppPriceCtrl,
                                    isNumber: true,
                                  ),
                                  _buildInput(
                                    'Support Days',
                                    supportDaysCtrl,
                                    isNumber: true,
                                  ),
                                  _buildInput(
                                    'Support Price (₹)',
                                    supportPriceCtrl,
                                    isNumber: true,
                                  ),

                                  // Calculated Total Box
                                  Container(
                                    margin: const EdgeInsets.only(top: 8),
                                    padding: const EdgeInsets.all(16),
                                    decoration: BoxDecoration(
                                      color: themeColors['lightBg1'],
                                      border: Border.all(
                                        color: themeColors['lightBorder'],
                                      ),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          'Calculated Total:',
                                          style: TextStyle(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w600,
                                            color: cGray700,
                                          ),
                                        ),
                                        const SizedBox(height: 8),
                                        Text(
                                          '₹${pricing['total']!.toStringAsFixed(0)}',
                                          style: TextStyle(
                                            fontSize: 24,
                                            fontWeight: FontWeight.bold,
                                            color: themeColors['secondary'],
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        const Text(
                                          'Including GST',
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: cGray600,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : null;

                      // RepaintBoundary must be the outermost wrapper so
                      // generatePdfData captures the FULL natural height of
                      // the continuous-flow content.
                      final previewCard = RepaintBoundary(
                        key: _previewKey,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            boxShadow: const [
                              BoxShadow(
                                color: Colors.black12,
                                blurRadius: 10,
                                offset: Offset(0, 4),
                              ),
                            ],
                          ),
                          child: _buildProposalPreview(
                            pricing,
                            today,
                            bonusDate,
                            themeColors,
                          ),
                        ),
                      );

                      if (isNarrow) {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            if (isEditing && editPanel != null) editPanel,
                            if (isEditing) const SizedBox(height: 24),
                            previewCard,
                          ],
                        );
                      }

                      return Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (isEditing && editPanel != null)
                            SizedBox(width: 360, child: editPanel),
                          if (isEditing) const SizedBox(width: 24),
                          Expanded(child: previewCard),
                        ],
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInput(
    String label,
    TextEditingController controller, {
    bool isNumber = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: cGray700,
            ),
          ),
          const SizedBox(height: 4),
          TextField(
            controller: controller,
            keyboardType: isNumber ? TextInputType.number : TextInputType.text,
            style: const TextStyle(fontSize: 14),
            decoration: InputDecoration(
              isDense: true,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 12,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(4),
                borderSide: const BorderSide(color: cGray300),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(4),
                borderSide: const BorderSide(color: cGray300),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(4),
                borderSide: const BorderSide(color: cBlue500),
              ),
            ),
            onChanged: (_) => setState(() {}),
          ),
        ],
      ),
    );
  }

  Widget _buildCheckListTile(String text, {Color? customColor}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '✓',
            style: TextStyle(
              color: customColor ?? cGreen600,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                color: cGray700,
                fontSize: 15,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProposalPreview(
    Map<String, double> pricing,
    String today,
    String bonusDate,
    Map<String, dynamic> theme,
  ) {
    final faqItems = _faqItems();

    return LayoutBuilder(
      builder: (context, constraints) {
        final double maxWidth = math.min(constraints.maxWidth, 900.0);

        // ── Continuous-flow layout ──────────────────────────────────────────
        // All sections flow one after another inside a single white column.
        // The PDF generator captures this full-height widget and slices it
        // into A4 pages automatically.
        return SizedBox(
          width: maxWidth,
          child: Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 32),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── HEADER ──────────────────────────────────────────────────
                _buildHeaderBlock(today, theme),
                const SizedBox(height: 24),

                // ── COVER / INTRO ────────────────────────────────────────────
                Text(
                  'Dear ${clientNameCtrl.text},',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: cGray900,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  'Thank you for considering Sidharth IT Solutions for your TallyPrime implementation. '
                  'We understand that managing accounting operations in the ${industry.toLowerCase()} '
                  'sector comes with unique challenges.',
                  style: const TextStyle(
                      fontSize: 14, color: cGray700, height: 1.55),
                ),
                const SizedBox(height: 10),
                const Text(
                  "Based on our conversation, we've prepared a complete solution that will help you:",
                  style: TextStyle(fontSize: 14, color: cGray700),
                ),
                const SizedBox(height: 12),
                _buildCheckListTile('Streamline GST compliance and filing',
                    customColor: theme['accent']),
                _buildCheckListTile('Reduce manual data entry and errors',
                    customColor: theme['accent']),
                _buildCheckListTile(
                    'Access your business data from anywhere on mobile',
                    customColor: theme['accent']),
                _buildCheckListTile(
                    'Get dedicated expert support when you need it',
                    customColor: theme['accent']),
                const SizedBox(height: 16),
                Align(
                  alignment: Alignment.centerRight,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: theme['lightBg1'],
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Text(
                      'Sidharth IT Solutions | Tally Certified Five Star Partner',
                      style: TextStyle(fontSize: 11, color: cGray600),
                    ),
                  ),
                ),

                _buildSectionDivider(),

                // ── BUSINESS PRIORITIES ──────────────────────────────────────
                Text(
                  '${clientNameCtrl.text} | Industry: $industry',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: theme['secondary'],
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Key Business Priorities We Noted',
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                      color: cGray900),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: const [
                    _InsightTile(
                      title: 'Accuracy & Compliance',
                      detail:
                          'GST-ready books, faster filings, audit readiness',
                    ),
                    _InsightTile(
                      title: 'Visibility on the Go',
                      detail:
                          'Mobile-first monitoring of stock, receivables, payables',
                    ),
                    _InsightTile(
                      title: 'Dedicated Support',
                      detail: 'Easy access to experienced Tally engineers',
                    ),
                  ],
                ),

                _buildSectionDivider(),

                // ── MOBILE HERO ──────────────────────────────────────────────
                const Text(
                  'Mobile Freedom Included',
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                    color: cGray900,
                  ),
                ),
                const SizedBox(height: 12),
                _buildMobileHero(pricing),
                const SizedBox(height: 8),
                const Text(
                  'This complimentary app stays FREE every year when you renew with Sidharth IT Solutions.',
                  style: TextStyle(fontSize: 12, color: cGray600),
                ),

                _buildSectionDivider(),

                // ── PACKAGE OVERVIEW ─────────────────────────────────────────
                const Text(
                  'Your Complete TallyPrime Solution',
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                    color: cGray900,
                  ),
                ),
                const SizedBox(height: 12),
                _buildPackageItem(
                  'TallyPrime 7 License (Single User)',
                  'Latest version with all features',
                  pricing['lPrice']!.toStringAsFixed(0),
                ),
                _buildPackageItem(
                  'Professional Installation & Setup',
                  'We configure everything for your business',
                  pricing['iPrice']!.toStringAsFixed(0),
                ),
                const SizedBox(height: 10),
                _buildFreeMobileCard(pricing),

                _buildSectionDivider(),

                // ── PACKAGE VALUE ────────────────────────────────────────────
                _buildPackageItem(
                  '${supportDaysCtrl.text} Days Expert Support',
                  'Phone + WhatsApp + Email',
                  pricing['sPrice']!.toStringAsFixed(0),
                  isLast: true,
                ),
                const SizedBox(height: 16),
                Divider(color: theme['lightBorder'], thickness: 2),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Total Service Value',
                            style:
                                TextStyle(fontSize: 13, color: cGray600)),
                        Text(
                          '₹${pricing['serviceValue']!.toStringAsFixed(0)}',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: cGray900,
                          ),
                        ),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        const Text('Your Investment (Before GST)',
                            style:
                                TextStyle(fontSize: 13, color: cGray600)),
                        Text(
                          '₹${pricing['packagePrice']!.toStringAsFixed(0)}',
                          style: TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                            color: theme['secondary'],
                          ),
                        ),
                        if (pricing['discount']! > 0)
                          Text(
                            '(${discountPercentCtrl.text}% discount applied)',
                            style: const TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: cGreen600,
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      vertical: 10, horizontal: 12),
                  decoration: BoxDecoration(
                    color: theme['lightBg2'],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    'Mobile app remains FREE when you renew annually with Sidharth IT Solutions.',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 13, color: cGray900),
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  'You save ₹${pricing['savings']!.toStringAsFixed(0)} in bundled services '
                  '(${(pricing['savings']! / pricing['serviceValue']! * 100).round()}% savings!)',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: theme['primary'],
                  ),
                ),

                _buildSectionDivider(),

                // ── INVESTMENT DETAILS ───────────────────────────────────────
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: cGray100,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Investment Details',
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                          color: cGray900,
                        ),
                      ),
                      const SizedBox(height: 12),
                      _buildInvestmentRow(
                        'TallyPrime License (MRP ₹${pricing['lPrice']!.toStringAsFixed(0)})',
                        '₹${pricing['lPrice']!.toStringAsFixed(0)}',
                        isStrikeThrough: true,
                      ),
                      _buildInvestmentRow(
                        'Special Discount (${discountPercentCtrl.text}%)',
                        '- ₹${pricing['discount']!.toStringAsFixed(0)}',
                        isGreen: true,
                      ),
                      const Divider(height: 24),
                      _buildInvestmentRow(
                        'Package Price',
                        '₹${pricing['packagePrice']!.toStringAsFixed(0)}',
                        isBold: true,
                      ),
                      _buildInvestmentRow(
                        'GST (18%)',
                        '₹${pricing['gst']!.toStringAsFixed(0)}',
                        isBold: true,
                      ),
                      const Divider(height: 24, thickness: 2),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Total Investment',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: cGray900,
                            ),
                          ),
                          Text(
                            '₹${pricing['total']!.toStringAsFixed(0)}',
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: cBlue600,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: cYellow50,
                          border: Border.all(color: cYellow300),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '🎁 Confirm by $bonusDate and get:',
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: cGray900,
                              ),
                            ),
                            const SizedBox(height: 6),
                            _buildCheckListTile(
                                'Priority installation within 48 hours'),
                            _buildCheckListTile(
                              'Extended support (${int.parse(supportDaysCtrl.text) + 15} days instead of ${supportDaysCtrl.text})',
                            ),
                            _buildCheckListTile(
                                'Mobile app setup and training included'),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'All values shown in Indian Rupees (₹).',
                  style: TextStyle(fontSize: 11, color: cGray600),
                ),

                _buildSectionDivider(),

                // ── TRUST ────────────────────────────────────────────────────
                _buildTrustSection(theme, margin: EdgeInsets.zero),

                const SizedBox(height: 16),

                // ── CTA ──────────────────────────────────────────────────────
                _buildReadyCtaSection(theme, margin: EdgeInsets.zero),

                _buildSectionDivider(),

                // ── CONTACT ──────────────────────────────────────────────────
                _buildContactFooter(theme, margin: EdgeInsets.zero),
                const SizedBox(height: 10),
                const Text(
                  'Call, WhatsApp, or email us to confirm. We will get you set up within 48 hours.',
                  style: TextStyle(fontSize: 13, color: cGray600),
                ),

                _buildSectionDivider(),

                // ── FAQ ──────────────────────────────────────────────────────
                _buildFaqSection(faqItems, showHeading: true),
                const SizedBox(height: 16),
                const Text(
                  'This proposal is valid for 15 days from the date mentioned above.',
                  style: TextStyle(fontSize: 13, color: cGray600),
                ),
                const SizedBox(height: 10),
                const Text(
                  'Sidharth IT Solutions\nAroundTally.com | sales@aroundtally.com\n'
                  'Tally Certified Five Star Partner | 20+ Years Serving 3,500+ Businesses',
                  style: TextStyle(
                      fontSize: 12, color: cGray700, height: 1.55),
                ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        );
      },
    );
  }

  /// Thin divider with consistent vertical breathing room used between sections.
  Widget _buildSectionDivider() {
    return const Padding(
      padding: EdgeInsets.symmetric(vertical: 20),
      child: Divider(color: cGray200, thickness: 1),
    );
  }

  // _buildCoverPage removed – content now flows continuously in _buildProposalPreview

  // _buildOpeningPage removed – content now flows continuously in _buildProposalPreview

  // _buildMobileHeroPage removed – content now flows continuously in _buildProposalPreview

  // _buildPackageOverviewPage removed – content now flows continuously in _buildProposalPreview

  // _buildPackageValuePage removed – content now flows continuously in _buildProposalPreview

  // _buildInvestmentPage removed – content now flows continuously in _buildProposalPreview

  // _buildTrustAndCtaPage removed – content now flows continuously in _buildProposalPreview

  // _buildContactPage removed – content now flows continuously in _buildProposalPreview

  // _buildFaqPage removed – content now flows continuously in _buildProposalPreview

  Widget _buildHeaderBlock(String today, Map<String, dynamic> theme) {
    return Container(
      padding: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: theme['secondary'], width: 4),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomPaint(size: const Size(72, 72), painter: LogoPainter()),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  'SIDHARTH IT SOLUTIONS',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: cGray900,
                  ),
                ),
                Text(
                  'Tally Certified Five Star Partner',
                  style: TextStyle(fontSize: 14, color: cGray600),
                ),
                Text(
                  'AroundTally.com',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: cBlue600,
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              const Text(
                'Proposal Date',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: cGray900,
                ),
              ),
              Text(
                today,
                style: const TextStyle(fontSize: 14, color: cGray600),
              ),
              const SizedBox(height: 8),
              Text(
                'Doc No: ${docNumberCtrl.text}',
                style: const TextStyle(fontSize: 14, color: cGray600),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMobileHero(Map<String, double> pricing) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [cGreen50, cEmerald50],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(color: cGreen400, width: 2),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: cGreen400.withValues(alpha: 0.2),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                '📱 FREE Mobile App Included',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: cGray900,
                ),
              ),
              const SizedBox(width: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: cYellow400,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  '₹${pricing['mPrice']!.toStringAsFixed(0)} VALUE',
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    color: cGray900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Text(
            'Run your business from your phone - FREE as long as you renew with Sidharth IT Solutions',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w600,
              color: cGray700,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  children: [
                    _buildCheckListTile(
                      'Check stock summary anytime, anywhere',
                    ),
                    _buildCheckListTile(
                      'View real-time business reports on your phone',
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Column(
                  children: [
                    _buildCheckListTile(
                      'Track outstanding receivables & payables',
                    ),
                    _buildCheckListTile(
                      'Make informed decisions on-the-go',
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: cGreen200),
              borderRadius: BorderRadius.circular(12),
            ),
            child: RichText(
              text: const TextSpan(
                style: TextStyle(fontSize: 14, color: cGray900),
                children: [
                  TextSpan(
                    text: 'Perfect for: ',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  TextSpan(
                    text:
                        'Business owners who travel, visit sites, or need to check business status while away from the office',
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFreeMobileCard(Map<String, double> pricing) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cGreen50,
        border: Border.all(color: cGreen300, width: 2),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text(
                'FREE Mobile App (Android)',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: cGray900,
                ),
              ),
              Text(
                'Stock, receivables & payables on your phone',
                style: TextStyle(fontSize: 13, color: cGray600),
              ),
              SizedBox(height: 4),
              _ExclusiveTag(),
            ],
          ),
          Text(
            '₹${pricing['mPrice']!.toStringAsFixed(0)}',
            style: const TextStyle(
              fontSize: 14,
              color: cGray400,
              decoration: TextDecoration.lineThrough,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionBadge(String label, Map<String, dynamic> theme) {
    return Align(
      alignment: Alignment.bottomRight,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        decoration: BoxDecoration(
          color: theme['lightBg1'],
          borderRadius: BorderRadius.circular(16),
        ),
        child: Text(
          label,
          style: const TextStyle(fontSize: 12, color: cGray600),
        ),
      ),
    );
  }

  List<Map<String, String>> _faqItems() {
    return [
      {
        'question':
            "Why is Sidharth IT Solutions' package better value than cheaper options?",
        'answer':
            'We bundle ₹31,000 worth of services for ₹21,375 (after 5% discount). Other partners charge separately for mobile app (₹4,500/year), installation (₹1,000), and ongoing support (₹3,000+). Our customers save significantly compared to buying these separately.',
      },
      {
        'question':
            "What happens to the mobile app if I don't renew with Sidharth IT Solutions?",
        'answer':
            'The mobile app is complimentary as long as you maintain your annual renewal with us. This ensures you always have the latest features and our dedicated support.',
      },
      {
        'question': 'How quickly can I start using TallyPrime?',
        'answer':
            'Most customers are fully operational within 48-72 hours. We handle installation, setup, and initial training to get you running smoothly.',
      },
      {
        'question': 'What kind of support do I get after installation?',
        'answer':
            'You get 45 days of expert support via phone, WhatsApp, and email. Our large support team ensures you get help when you need it. After 45 days, you can continue with our annual support plan.',
      },
      {
        'question': 'Can you integrate TallyPrime with my existing systems?',
        'answer':
            'Yes! We specialize in numerous integrations – banking, e-commerce platforms, inventory systems, and more. We’ll assess your needs and provide a customized solution.',
      },
    ];
  }

  Widget _buildPackageItem(
    String title,
    String subtitle,
    String priceText, {
    bool isLast = false,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      margin: EdgeInsets.only(bottom: isLast ? 0 : 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: cGray900,
                ),
              ),
              Text(
                subtitle,
                style: const TextStyle(fontSize: 13, color: cGray600),
              ),
            ],
          ),
          Text(
            '₹$priceText',
            style: const TextStyle(
              fontSize: 14,
              color: cGray400,
              decoration: TextDecoration.lineThrough,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInvestmentRow(
    String title,
    String value, {
    bool isStrikeThrough = false,
    bool isGreen = false,
    bool isBold = false,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 15,
              fontWeight: (isBold || isGreen)
                  ? FontWeight.w600
                  : FontWeight.normal,
              color: isGreen ? cGreen700 : cGray700,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 15,
              fontWeight: (isBold || isGreen)
                  ? FontWeight.bold
                  : FontWeight.normal,
              color: isGreen
                  ? cGreen700
                  : (isStrikeThrough ? cGray400 : cGray900),
              decoration: isStrikeThrough
                  ? TextDecoration.lineThrough
                  : TextDecoration.none,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTrustSection(
    Map<String, dynamic> theme, {
    EdgeInsetsGeometry? margin,
  }) {
    final trustHighlights = [
      (
        icon: LucideIcons.award,
        title: '20+ Years of Excellence',
        subtitle: 'Tally Certified Five Star Partner since 2002',
      ),
      (
        icon: LucideIcons.users,
        title: 'Largest Support Team in Kerala',
        subtitle: 'Expert help available when you need it most',
      ),
      (
        icon: LucideIcons.zap,
        title: 'Fast Response Times',
        subtitle: 'Get answers quickly via phone, WhatsApp, or email',
      ),
      (
        icon: LucideIcons.link,
        title: 'Numerous Integrations',
        subtitle: 'Connect Tally with banking, e-commerce, and more',
      ),
    ];

    return Container(
      width: double.infinity,
      margin: margin ?? const EdgeInsets.only(bottom: 32),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: cGray200),
        boxShadow: const [
          BoxShadow(color: Colors.black12, offset: Offset(0, 2), blurRadius: 6),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Why 3,500+ Businesses Trust Sidharth IT Solutions',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: cGray900,
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 16,
            runSpacing: 16,
            children: trustHighlights
                .map(
                  (stat) => _buildTrustTile(
                    icon: stat.icon,
                    title: stat.title,
                    subtitle: stat.subtitle,
                    accentColor: theme['secondary'],
                  ),
                )
                .toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildTrustTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color accentColor,
  }) {
    return Container(
      width: 250,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cGray50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: cGray200),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: accentColor.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, size: 20, color: accentColor),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: cGray900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(fontSize: 13, color: cGray600),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReadyCtaSection(
    Map<String, dynamic> theme, {
    EdgeInsetsGeometry? margin,
  }) {
    return Container(
      width: double.infinity,
      margin: margin ?? const EdgeInsets.only(bottom: 24),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: cBlue200),
        boxShadow: const [
          BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0, 3)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Ready to Get Started?',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: cGray900,
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Contact Us to Confirm Your Order',
            style: TextStyle(
              fontSize: 16,
              color: cGray700,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 16),
          _buildContactLine(
            icon: LucideIcons.phoneCall,
            label: '+91 9388513999  |  +91 9388613999',
            color: theme['secondary'],
          ),
          const SizedBox(height: 8),
          _buildContactLine(
            icon: LucideIcons.mail,
            label: 'sales@aroundtally.com',
            color: theme['secondary'],
          ),
          const SizedBox(height: 16),
          const Text(
            "Call, WhatsApp, or email us to confirm. We'll get you set up within 48 hours.",
            style: TextStyle(fontSize: 14, color: cGray600),
          ),
        ],
      ),
    );
  }

  Widget _buildContactFooter(
    Map<String, dynamic> theme, {
    EdgeInsetsGeometry? margin,
  }) {
    return Container(
      width: double.infinity,
      margin: margin ?? const EdgeInsets.only(bottom: 24),
      decoration: BoxDecoration(
        color: cSlate800,
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 10,
            offset: Offset(0, 6),
          ),
        ],
      ),
      padding: const EdgeInsets.all(28),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final isStacked = constraints.maxWidth < 700;
          final officeSection = Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text(
                'Sidharth IT Solutions',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 16),
              Text(
                'Office Address',
                style: TextStyle(
                  color: cGray100,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 6),
              Text(
                'LIG 838, Panampilly Nagar\nErnakulam, Kerala',
                style: TextStyle(color: Colors.white70, height: 1.4),
              ),
            ],
          );

          final contactSection = Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text(
                'Contact Details',
                style: TextStyle(
                  color: cGray100,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 6),
              _ContactDetailRow(
                icon: LucideIcons.phoneCall,
                text: '9388513999, 9388613999, 9399919399',
              ),
              SizedBox(height: 6),
              _ContactDetailRow(
                icon: LucideIcons.mail,
                text: 'sales@aroundtally.com',
              ),
              SizedBox(height: 6),
              _ContactDetailRow(
                icon: LucideIcons.globe,
                text: 'www.aroundtally.com',
              ),
            ],
          );

          return isStacked
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    officeSection,
                    const SizedBox(height: 24),
                    contactSection,
                  ],
                )
              : Row(
                  children: [
                    Expanded(child: officeSection),
                    const SizedBox(width: 32),
                    Expanded(child: contactSection),
                  ],
                );
        },
      ),
    );
  }

  Widget _buildFaqSection(
    List<Map<String, String>> faqs, {
    bool showHeading = false,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: cGray200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (showHeading) ...[
            const Text(
              'Common Questions',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: cGray900,
              ),
            ),
            const SizedBox(height: 16),
          ],
          ...faqs.map((faq) => _buildFaqTile(faq['question']!, faq['answer']!)),
        ],
      ),
    );
  }

  Widget _buildFaqTile(String question, String answer) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cGray50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: cGray200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            question,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w600,
              color: cGray900,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            answer,
            style: const TextStyle(fontSize: 14, color: cGray600, height: 1.5),
          ),
        ],
      ),
    );
  }

  Widget _buildContactLine({
    required IconData icon,
    required String label,
    required Color color,
  }) {
    return Row(
      children: [
        Icon(icon, size: 18, color: color),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            label,
            style: const TextStyle(fontSize: 15, color: cGray800),
          ),
        ),
      ],
    );
  }
}

class _InsightTile extends StatelessWidget {
  const _InsightTile({required this.title, required this.detail});

  final String title;
  final String detail;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 240,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cGray50,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: cGray200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w600,
              color: cGray900,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            detail,
            style: const TextStyle(fontSize: 13, color: cGray600, height: 1.4),
          ),
        ],
      ),
    );
  }
}

class _ExclusiveTag extends StatelessWidget {
  const _ExclusiveTag();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: cGreen600,
        borderRadius: BorderRadius.circular(4),
      ),
      child: const Text(
        '⭐ EXCLUSIVE - Other partners charge separately',
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
    );
  }
}

class _ContactDetailRow extends StatelessWidget {
  const _ContactDetailRow({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, color: Colors.white, size: 16),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            text,
            style: const TextStyle(color: Colors.white70, fontSize: 14),
          ),
        ),
      ],
    );
  }
}